# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['coffee', 'coffee.lib', 'coffee.lib.holder']

package_data = \
{'': ['*']}

install_requires = \
['numpy==1.18.2', 'scipy==1.2.3', 'solidpython==0.4.7', 'toml>=0.9,<0.10']

setup_kwargs = {
    'name': 'coffee',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'lewoudar',
    'author_email': 'XXX@XXX.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
